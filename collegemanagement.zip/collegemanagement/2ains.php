<?php    
  
    $event=$_POST['event'];  
        $date=$_POST['date'];  
   $time=$_POST['time'];
    $con=mysqli_connect('localhost','root','') or die(mysql_error());  
    mysqli_select_db($con,'mini') or die("cannot select DB");  
  

    $sql="INSERT INTO 2ass(aname,date,time) VALUES('$event','$date','$time')";  
  
    $result=mysqli_query($con,$sql);  
        if($result==true){  
                        
  header("refresh:1;url=2ass.php");
    } else {  
    echo "Failure!";  
    }  
  

 
 
?>  
