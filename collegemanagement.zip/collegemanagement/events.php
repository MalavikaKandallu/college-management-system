<html>
<head>
<title>EVENTS</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url('img6.jpg');"color:white", class="body">
<div class="menu-bar">
<ul>
<p color:"white"> EVENTS</p>
<li><a href="faculty.php" style="color:white">FACULTY DETAILS</a></li>
		<li><a href="eins.html" style="color:white">INSERT</a></li>
		<li><a href="edel.html" style="color:white">DELETE</a></li>	
		<li><a href="loginas.html" style="color:white">LOG OUT</a></li>
</ul>
</div>
<br><br><br><br>



<table class="table">
                    
                    <th class="th">Date</th> 
                    <th class="th">Time</th>
                   <th class="th">Events</th>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mini";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Date,Time,Events FROM events";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
             
                $Date=$row['Date'];
	        $Time=$row['Time']; 
	        $Events=$row['Events'];
                echo"
                <tr class='td'>
	
		              <td class='td'>$Date</td>
                	<td class='td'>$Time</td> 
	                 <td class='td'>$Events</td> 
                  
                </tr>";
        }
 
  }
else {
 echo "0 results";
}
$conn->close();
?>
<div class="side-bar">
</div>
</table>
</body>
</html>