<?php  
    include 'style.css';
    $con=mysqli_connect('localhost','root','') or die(mysql_error());  
    mysqli_select_db($con,'mini') or die("cannot select DB");  
    $id=$_GET['id'];
    $rt=$_GET['rt']; 
      $mno=$_GET['mno'];
      $add=$_GET['add'];
        $ecn=$_GET['ecn'];
 ?> 
<html>
<head>
    <title>EDIT</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body  style="background-image: url('img6.jpg');" color:black">
<nav>
    <div class='bar1'>
      <lable>EDIT DETAILS</lable>   
</nav>
<div class='container'>
    <div class='card'>
<form action="fupdate.php" method="get">
<label class="modal1">ID: <input type="text" class="modal1" name="id" value="<?php echo "$id" ?>"></label><br>
<label>NAME: <input type="text" class="name1" name="name" value="<?php echo "$rt" ?>" ></label><br>
<label>MOBILE NUMBER: <input type="text" class="name1" name="mno" value="<?php echo "$mno" ?>" ></label><br>
<label>ADDRESS: <input type="text" class="name1" name="add" value="<?php echo "$add" ?>" ></label><br>
<label>EMERGENCY CONTACT NUMBER: <input type="text" class="name1" name="ecn" value="<?php echo "$ecn" ?>" ></label><br>
<center><input type="submit" name="submit" class="glow-on-hover" value="UPDATE"></center>
</div>
</div>
</body>
</html> 
