<html>
<head>
<title>IV YEAR CSE</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url(img17.jpg);"color:white", class="body">
<div class="menu-bar">
<ul>
<p color:"white"> IV YEAR CSE</p>
   <li><a href="1styr.html" style="color:white">I YEAR</a></li>
    <li><a href="2ndyr.html" style="color:white">II YEAR</a></li>
    <li><a href="3rdyr.html" style="color:white">III YEAR</a></li> 
    <li><a href="4thyr.html" style="color:white">IV YEAR</a></li>
		<li><a href="4ins.html" style="color:white">INSERT</a></li>
		<li><a href="4del.html" style="color:white">DELETE</a></li>	
		<li><a href="login.html" style="color:white">LOG OUT</a></li>
</ul>
</div>
<br><br><br><br>



<table class="table">
                    
                    <th class="th">Register_number</th> 
                    <th class="th">Name</th>   
                    <th class="th">update</th>
                    

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mini";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Name,Register_number FROM 4nl";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
             
                $rn=$row['Register_number'];
                $Name=$row['Name']; 
                echo"
                <tr>
	
		<td class='td'>$rn</td>
     <td class='td'> $Name</td>
<td class='td'><a href='4edit.php?rn=$rn&rt=$Name'>EDIT </a>
                  
                </tr>";
        }
 
  }
else {
 echo "0 results";
}
$conn->close();
?>
<div class="side-bar">
</div>
</table>
</body>
</html>