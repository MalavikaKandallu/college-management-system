<html>
<head>
<title>IV YEAR CSE IAT MARKS</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url(img17.jpg);"color:white", class="body">
<div class="menu-bar">
<ul>
<p color:"white"> IV YEAR CSE IAT MARKS</p>
<li><a href="1styr.html" style="color:white">I YEAR</a></li>
    <li><a href="2ndyr.html" style="color:white">II YEAR</a></li>
    <li><a href="3rdyr.html" style="color:white">III YEAR</a></li> 
    <li><a href="4thyr.html" style="color:white">IV YEAR</a></li>
		<li><a href="login.html" style="color:white">LOG OUT</a></li>
</ul>
</div>
<br><br><br><br>



<center>
<table class="table">
                    
                    <th class="th">Name</th>
<th class="th">subject1</th> 
<th class="th">subject2</th> 
<th class="th">subject3</th> 
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mini";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT stname,sub1,sub2,sub3 FROM 4iat";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
             

	        $stname=$row['stname']; 
                $sub1=$row['sub1'];
                $sub2=$row['sub2'];
                $sub3=$row['sub3'];

                echo"
                <tr class='td'>

                	<td class='td'>$stname</td> 
                  		<td class='td'>$sub1</td>
       		<td class='td'>$sub2</td>
       		<td class='td'>$sub3</td>


                </tr>";
        }
 
  }
else {
 echo "0 results";
}
$conn->close();
?>
<div class="side-bar">
</div>
</table>
</center>
</body>
</html>