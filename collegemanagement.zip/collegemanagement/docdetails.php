<html>
<head>
<title>ONLINE DOCTOR APPOINTMENT SYSTEM</title>
<link rel="stylesheet" href="style1.css">
</head>
<body style="background-image: url(img11.jpg);"color:white", class="body">
<div class="menu-bar">
<ul>
<p color:"white">ONLINE DOCTOR APPOINTMENT SYSTEM</p>
<li><a href="1styr.html" style="color:white">I YEAR</a></li>
    <li><a href="2ndyr.html" style="color:white">II YEAR</a></li>
    <li><a href="3rdyr.html" style="color:white">III YEAR</a></li> 
    <li><a href="4thyr.html" style="color:white">IV YEAR</a></li>
		<li><a href="1ains.html" style="color:white">INSERT</a></li>
		<li><a href="1adel.html" style="color:white">DELETE</a></li>	
		<li><a href="login.html" style="color:white">LOG OUT</a></li>
</ul>
</div>
<br><br><br><br>



<table class="table">
                    
                    <th class="th">ASSIGNMENT NAME</th> 
                    <th class="th">DATE</th>
			<th class="th">TIME</th>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mini";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT aname, date,time FROM 1ass";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
             
                $aname=$row['aname'];
	        $date=$row['date']; 
		 $time=$row['time'];
                echo"
                <tr class='td'>
	
		<td class='td'>$aname</td>
                	<td class='td'>$date</td> 
                  <td class='td'>$time</td> 
                </tr>";
        }
 
  }
else {
 echo "0 results";
}
$conn->close();
?>
<div class="side-bar">
</div>
</table>
</body>
</html>