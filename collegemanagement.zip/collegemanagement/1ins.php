<?php    
  
    $streg=$_POST['streg'];  
        $stname=$_POST['stname'];  
    $con=mysqli_connect('localhost','root','') or die(mysql_error());  
    mysqli_select_db($con,'mini') or die("cannot select DB");  
  

    $sql="INSERT INTO 1nl(Register_number , Name) VALUES('$streg','$stname')";  
  
    $result=mysqli_query($con,$sql);  
        if($result==true){  
                        
  header("refresh:1;url=1nl.php");
    } else {  
    echo "Failure!";  
    }  
?>  
