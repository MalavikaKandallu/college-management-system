
<?php  
if($_GET['submit'])
{
    $conn=mysqli_connect('localhost','root','') or die(mysql_error());  
    mysqli_select_db($conn,'mini') or die("cannot select DB");  
    $id=$_GET['id'];
    $name=$_GET['name'];
$sql="UPDATE 1nl SET Register_number='$id',Name='$name' WHERE Register_number='$id'";
$result=$conn->query($sql);
if($result==true){
    echo "<script>alert('UPDATE COMPLETED SUCCESSFULLY')</script>";
    header("refresh:1;url=1nl.php");
}
else{
    echo "failed";
}
}
 ?> 