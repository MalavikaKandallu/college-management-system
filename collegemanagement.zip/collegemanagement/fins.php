<?php     
        $fname=$_POST['fname'];  
      $id=$_POST['id']; 
      $mnum=$_POST['mnum']; 
      $add=$_POST['add']; 
      $ecn=$_POST['ecn']; 
    $con=mysqli_connect('localhost','root','') or die(mysql_error());  
    mysqli_select_db($con,'mini') or die("cannot select DB");  
  

    $sql="INSERT INTO faculty(Name , id, mobile_number , address , emergency_contact_number) VALUES('$fname', '$id','$mnum','$add','$ecn')";  
  
    $result=mysqli_query($con,$sql);  
        if($result==true){  
                        
  header("refresh:1;url=faculty.php");
    } else {  
    echo "Failure!";  
    }  
?>  
