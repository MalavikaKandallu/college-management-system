<html>
<head>
<title>FACULTY DETAILS</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url('img6.jpg');"color:white", class="body">
<div class="menu-bar">
<ul>
<p color:"white">FACULTY DETAILS</p>
		<li><a href="events.php" style="color:white">MANAGE EVENTS</a></li>
		<li><a href="fins.html" style="color:white">INSERT</a></li>
		<li><a href="fdel.html" style="color:white">DELETE</a></li>	
		<li><a href="loginas.html" style="color:white">LOG OUT</a></li>
</ul>
</div>
<br><br><br><br>



<table class="table">
       <th class="th">NAME</th>
			<th class="th">ID</th>
			  <th class="th">CONTACT NUMBER</th>
			  <th class="th">ADDRESS</th>
			  <th class="th">EMERGENCY CONTACT NUMBER</th>
			   <th class="th">UPDATE</th>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mini";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Name,id,mobile_number,address,emergency_contact_number FROM faculty";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
	        			$Name=$row['Name']; 
                $id=$row['id'];
                $mobile_number=$row['mobile_number'];
                $address=$row['address'];
                $emergency_contact_number=$row['emergency_contact_number'];

                echo"
                <tr class='td'>
                	<td class='td'>$Name</td> 
									<td class='td'>$id</td>
									<td class='td'>$mobile_number</td>
		              <td class='td'>$address</td>
		              <td class='td'>$emergency_contact_number</td>  
		              <td class='td'><a href='fedit.php?id=$id&rt=$Name&mno=$mobile_number&add=$address&ecn=$emergency_contact_number'>EDIT </a>                
                </tr>";
        }
 
  }
else {
 echo "0 results";
}
$conn->close();
?>
<div class="side-bar">
</div>
</table>
</body>
</html>