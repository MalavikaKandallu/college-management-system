<?php  
    include 'style.css';
    $con=mysqli_connect('localhost','root','') or die(mysql_error());  
    mysqli_select_db($con,'mini') or die("cannot select DB");  
    $rn=$_GET['rn'];
    $rt=$_GET['rt'];
 ?> 
<html>
<head>
    <title>shop</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body style="background-image: url(img17.jpg);" color:black">
<nav class="navig">
    <div class='bar1'>
      <lable>EDIT DETAILS</lable>   
</nav>
<div class='container'>
    <div class='card'>
<form action="4update.php" method="get">
<label class="modal1">ID: <input type="text" class="modal1" name="id" value="<?php echo "$rn" ?>"></label><br>
<label>NAME: <input type="text" class="name" name="name" value="<?php echo "$rt" ?>" ></label><br>
<center><input type="submit" name="submit" class="glow-on-hover" value="UPDATE"></center>
</div>
</div>
</body>
</html> 
