<?php    
  
    $date=$_POST['date'];  
	
    $con=mysqli_connect('localhost','root','') or die(mysql_error());  
    mysqli_select_db($con,'mini') or die("cannot select DB");  
  

    $sql="DELETE FROM events WHERE Events = '$date'";  
  
    $result=mysqli_query($con,$sql);  
        if($result==true){  
                        
  header("refresh:1;url=events.php");
    } else {  
    echo "Failure!";  
    }  
?>  
