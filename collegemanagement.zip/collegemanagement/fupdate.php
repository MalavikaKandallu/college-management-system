
<?php  
if($_GET['submit'])
{
    $conn=mysqli_connect('localhost','root','') or die(mysql_error());  
    mysqli_select_db($conn,'mini') or die("cannot select DB");  
    $id=$_GET['id'];
    $name=$_GET['name']; 
      $mno=$_GET['mno'];
      $add=$_GET['add'];
        $ecn=$_GET['ecn'];
$sql="UPDATE faculty SET id='$id',Name='$name',mobile_number='$mno',address='$add',emergency_contact_number='$ecn'WHERE id='$id'";
$result=$conn->query($sql);
if($result==true){
    echo "<script>alert('UPDATE COMPLETED SUCCESSFULLY')</script>";
    header("refresh:1;url=faculty.php");
}
else{
    echo "failed";
}
}
 ?> 